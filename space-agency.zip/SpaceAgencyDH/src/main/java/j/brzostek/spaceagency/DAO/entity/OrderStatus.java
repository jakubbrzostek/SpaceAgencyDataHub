package j.brzostek.spaceagency.DAO.entity;

public enum OrderStatus {
    PAID
}
